#!/usr/bin/env python3
"""
AI Game Bot - Web Application Startup Script
This script provides easy startup for the web application with proper configuration.
"""

import os
import sys
import subprocess
import platform

def check_dependencies():
    """Check if required dependencies are installed."""
    try:
        import flask
        import cv2
        import numpy
        import PIL
        print("✓ All core dependencies found")
        return True
    except ImportError as e:
        print(f"✗ Missing dependency: {e}")
        print("Installing dependencies...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        return True

def setup_environment():
    """Setup environment variables and configuration."""
    # Set default port if not specified
    if not os.getenv('PORT'):
        os.environ['PORT'] = '5000'
    
    # Create logs directory if it doesn't exist
    os.makedirs('logs', exist_ok=True)
    
    # Check for API keys
    api_keys = ['OPENAI_API_KEY', 'ANTHROPIC_API_KEY']
    missing_keys = [key for key in api_keys if not os.getenv(key)]
    
    if missing_keys:
        print("⚠️  Optional API keys not found:")
        for key in missing_keys:
            print(f"   - {key}")
        print("   The bot will work with limited AI features.")
        print("   Add API keys as environment variables for full functionality.")
    else:
        print("✓ All API keys configured")

def start_application():
    """Start the AI Game Bot web application."""
    print("🤖 Starting AI Game Bot Web Application...")
    print(f"🌐 Platform: {platform.system()}")
    print(f"🐍 Python: {sys.version}")
    
    if check_dependencies():
        setup_environment()
        
        port = os.getenv('PORT', '5000')
        print(f"🚀 Starting server on port {port}")
        print(f"📱 Access the bot at: http://localhost:{port}")
        print("=" * 50)
        
        # Import and run the main application
        try:
            import main
            sys.argv = ['main.py', '--web']
            main.main()
        except KeyboardInterrupt:
            print("\n🛑 Shutting down gracefully...")
        except Exception as e:
            print(f"❌ Error starting application: {e}")
            sys.exit(1)

if __name__ == "__main__":
    start_application()