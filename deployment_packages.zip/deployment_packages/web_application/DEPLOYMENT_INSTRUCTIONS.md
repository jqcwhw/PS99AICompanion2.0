# AI Game Bot - Web Application Deployment

## Overview
This package contains the complete AI Game Bot web application ready for deployment on any server or cloud platform.

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Set Environment Variables (Optional)
For enhanced functionality, set these API keys:
```bash
export OPENAI_API_KEY="your_openai_api_key"
export ANTHROPIC_API_KEY="your_anthropic_api_key"
```

### 3. Run the Application
```bash
python main.py --web
```

The application will start on `http://localhost:5000`

## Cloud Deployment Options

### Heroku Deployment
1. Create a `Procfile`:
```
web: python main.py --web
```

2. Deploy:
```bash
git init
git add .
git commit -m "Initial commit"
heroku create your-app-name
git push heroku main
```

### Railway Deployment
1. Create account at railway.app
2. Connect GitHub repository
3. Add environment variables in Railway dashboard
4. Deploy automatically

### Render Deployment
1. Create account at render.com
2. Connect repository
3. Set build command: `pip install -r requirements.txt`
4. Set start command: `python main.py --web`

### DigitalOcean App Platform
1. Create account at digitalocean.com
2. Use App Platform
3. Connect repository
4. Configure environment variables

## Environment Variables
- `OPENAI_API_KEY`: For AI language processing features
- `ANTHROPIC_API_KEY`: For advanced AI capabilities
- `PORT`: Server port (default: 5000)

## Features Included
✓ Interactive training system for game automation
✓ Computer vision for game element detection
✓ Natural language command processing
✓ Zone mapping and boundary creation
✓ Macro recording and playback
✓ Knowledge base management
✓ Real-time web dashboard
✓ Learning material storage

## File Structure
```
web_application/
├── core/                  # Main bot systems
├── data/                  # Knowledge base and game data
├── static/                # Web interface assets
├── templates/             # HTML templates
├── utils/                 # Utility functions
├── attached_assets/       # Reference automation files
├── logs/                  # Application logs
├── main.py               # Main application entry
├── app.py                # Flask web server
└── requirements.txt       # Python dependencies
```

## Security Notes
- Keep API keys secure
- Use environment variables for sensitive data
- Consider firewall rules for production deployment
- Enable HTTPS in production

## Support
Refer to README.md for detailed feature documentation and usage instructions.